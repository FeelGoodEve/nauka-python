a = 10
b = 5
c = "jabłko"
d = "pomarańcza"

print(a == b)  # False
print(a != b)  # True
print(a < b)   # False
print(a > b)   # True
print(c < d)   # True (porównanie alfabetyczne)
print(c >= d)  # False