licznik = 1  # Inicjalizacja licznika

while licznik <= 5:  # Warunek pętli
    print(f"Licznik: {licznik}")  # Wyświetlenie wartości licznika
    licznik += 1  # Zwiększenie wartości licznika