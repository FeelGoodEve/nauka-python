print("Mój pierwszy skrypt")
print("Mój pierwszy skrypt")
