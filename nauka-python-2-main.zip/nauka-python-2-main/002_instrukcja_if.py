wiek = 20

if wiek >= 18:
    print("Jesteś pełnoletni.")