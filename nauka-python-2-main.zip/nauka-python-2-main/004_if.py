wiek = 20
prawo_jazdy = True

if wiek >= 18:
    if prawo_jazdy:
        print("Możesz prowadzić samochód.")
    else:
        print("Jesteś pełnoletni, ale nie masz prawa jazdy.")