ocena = 4

if ocena == 6:
    print("Celujący!")
elif ocena == 5:
    print("Bardzo dobry!")
elif ocena >= 3:
    print("Dostateczny.")
else:
    print("Niestety, niedostateczny.")