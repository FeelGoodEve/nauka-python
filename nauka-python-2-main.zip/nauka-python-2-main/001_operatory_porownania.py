x = 7
y = 12
z = 5

print(x > 5 and y < 15)  # True
print(x < 3 or z == 5)   # True
print(not (x == y))      # True