# komnentarz

