if wiek >= 18:
print("Jesteś pełnoletni.")