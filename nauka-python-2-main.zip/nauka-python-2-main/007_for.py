for liczba in range(10):
    if liczba % 2 == 0:  # Pomijaj liczby parzyste
        continue
    print(liczba)