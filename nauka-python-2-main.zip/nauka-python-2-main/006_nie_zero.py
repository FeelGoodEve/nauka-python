liczba = 5

if liczba:
    print("Liczba jest różna od 0, więc warunek jest spełniony.")
else:
    print("Liczba jest równa 0, więc warunek nie jest spełniony.")