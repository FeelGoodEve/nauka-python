# **Podstawy programowania w Python**  
## **Podstawy programowania w Python**  
### **Podstawy programowania w Python**

To jest podstawowy opis.  
To jest dalsza czesc opisu

- to jest pierwszy element listy  
- to jest drugi element listy  

```shell
pip install numpy
```

### **Wymagania**
Mianimalna wersja python 3.11

### **Instrukaja instalacji - lista krokow **

```shell
python -m venv .venv
```
```shell
.venv/Scripts/activate
```


```shell
pip install -r requirements.txt 
```